package com.example.moidengi

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF101411)
private val SurfaceDark = Color(0xFF1B211D)
private val Green = Color(0xFF9BE6A8)
private val Red = Color(0xFFFF8A80)
private val Muted = Color(0xFFADB8AF)

data class Transaction(
    val id: Long,
    val title: String,
    val amount: Double,
    val isIncome: Boolean,
    val category: String,
    val date: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg,
                    surface = SurfaceDark,
                    primary = Green,
                    secondary = Green,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                ExpenseApp(this)
            }
        }
    }
}

@Composable
private fun ExpenseApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("moi_dengi", Context.MODE_PRIVATE) }
    var transactions by remember { mutableStateOf(loadTransactions(prefs)) }
    var showAdd by remember { mutableStateOf(false) }
    var incomeMode by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val monthFormat = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()) }
    val currentMonth = monthFormat.format(Date(now))
    val monthTransactions = transactions.filter { monthFormat.format(Date(it.date)) == currentMonth }
    val income = monthTransactions.filter { it.isIncome }.sumOf { it.amount }
    val expenses = monthTransactions.filter { !it.isIncome }.sumOf { it.amount }
    val balance = income - expenses

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(26.dp))
            Text("Мои деньги", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Твои финансы — под контролем", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("ИТОГ ЗА МЕСЯЦ", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(formatSek(balance), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = if (balance >= 0) Green else Red)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryItem("Доходы", formatSek(income), Green, Modifier.weight(1f))
                        SummaryItem("Расходы", formatSek(expenses), Red, Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { incomeMode = false; showAdd = true },
                    modifier = Modifier.weight(1f).height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF122016)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.ArrowUpward, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Расход")
                }
                OutlinedButton(
                    onClick = { incomeMode = true; showAdd = true },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.ArrowDownward, null, tint = Green)
                    Spacer(Modifier.width(6.dp))
                    Text("Доход", color = Green)
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Последние операции", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${transactions.size} всего", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))

            if (transactions.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(58.dp).background(SurfaceDark, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Add, null, tint = Green, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Пока нет операций", fontWeight = FontWeight.SemiBold)
                        Text("Добавь первую покупку или доход", color = Muted, fontSize = 13.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(transactions.sortedByDescending { it.date }, key = { it.id }) { item ->
                        TransactionRow(item, onDelete = {
                            transactions = transactions.filterNot { it.id == item.id }
                            saveTransactions(prefs, transactions)
                        })
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddTransactionDialog(
            incomeMode = incomeMode,
            onDismiss = { showAdd = false },
            onSave = { title, amount, category ->
                val newItem = Transaction(
                    id = System.currentTimeMillis(),
                    title = title,
                    amount = amount,
                    isIncome = incomeMode,
                    category = category,
                    date = System.currentTimeMillis()
                )
                transactions = listOf(newItem) + transactions
                saveTransactions(prefs, transactions)
                showAdd = false
            }
        )
    }
}

@Composable
private fun SummaryItem(label: String, amount: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(label, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text(amount, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TransactionRow(item: Transaction, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(42.dp).background(if (item.isIncome) Color(0xFF243B2A) else Color(0xFF3A2827), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (item.isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    null,
                    tint = if (item.isIncome) Green else Red
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    "${item.category} · ${SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(item.date))}",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (if (item.isIncome) "+" else "−") + formatSek(item.amount),
                    color = if (item.isIncome) Green else Red,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    Icons.Default.Delete, contentDescription = "Удалить операцию",
                    tint = Muted, modifier = Modifier.size(18.dp).clickable { onDelete() }
                )
            }
        }
    }
}

@Composable
private fun AddTransactionDialog(
    incomeMode: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(if (incomeMode) "Зарплата" else "Еда") }
    var expanded by remember { mutableStateOf(false) }
    val categories = if (incomeMode)
        listOf("Зарплата", "Подарок", "Возврат", "Другое")
    else listOf("Еда", "Транспорт", "Жильё", "Покупки", "Здоровье", "Развлечения", "Другое")
    val amount = amountText.replace(',', '.').toDoubleOrNull()
    val valid = title.isNotBlank() && amount != null && amount > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text(if (incomeMode) "Новый доход" else "Новый расход") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Название") }, singleLine = true
                )
                OutlinedTextField(
                    value = amountText, onValueChange = { amountText = it },
                    label = { Text("Сумма, SEK") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Категория: $category")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { option ->
                            DropdownMenuItem(text = { Text(option) }, onClick = { category = option; expanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (valid && amount != null) onSave(title.trim(), amount, category) }, enabled = valid) {
                Text("Сохранить", color = Green)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

private fun formatSek(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("sv", "SE"))
    formatter.minimumFractionDigits = 0
    formatter.maximumFractionDigits = 2
    return "${formatter.format(amount)} kr"
}

private fun loadTransactions(prefs: android.content.SharedPreferences): List<Transaction> {
    return try {
        val array = JSONArray(prefs.getString("transactions", "[]") ?: "[]")
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Transaction(
                id = o.getLong("id"),
                title = o.getString("title"),
                amount = o.getDouble("amount"),
                isIncome = o.getBoolean("isIncome"),
                category = o.getString("category"),
                date = o.getLong("date")
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveTransactions(prefs: android.content.SharedPreferences, transactions: List<Transaction>) {
    val array = JSONArray()
    transactions.forEach { item ->
        array.put(JSONObject().apply {
            put("id", item.id)
            put("title", item.title)
            put("amount", item.amount)
            put("isIncome", item.isIncome)
            put("category", item.category)
            put("date", item.date)
        })
    }
    prefs.edit().putString("transactions", array.toString()).apply()
}
